import Papa from 'papaparse';

export const load = async ({ fetch }) => {
  const response = await fetch('data/Purchases.csv');
  const csvText = await response.text();
  const { data } = Papa.parse(csvText, { header: true });

  const purchases = data.map(purchase => {
    const plannedDate = new Date(purchase.PlannedGoodsReceiptDate);
    const actualDate = new Date(purchase.ActualGoodsReceiptDate);
    const delay = (+actualDate - +plannedDate) / (86400000); // milliseconds to days
    let category = 'more than 3 days late';
    if (delay < 0) category = 'early';
    else if (delay === 0) category = 'on-time';
    else if (delay <= 3) category = '1-3 days late';

    return {
      ...purchase,
      Year: plannedDate.getFullYear(),
      Month: plannedDate.getMonth() + 1, // JavaScript months are 0-indexed
      DelayCategory: category,
      Delay: delay
    };
  });

  // Extract unique years and distribution centers
  const years = [...new Set(purchases.map(p => p.Year))].sort();
  const plantKeys = [...new Set(purchases.map(p => p.PlantKey))].sort();
  const categories = ['early', 'on-time', '1-3 days late', 'more than 3 days late'];

  // Generate the output grouped by year, month, and PlantKey
  const output = years.map(year => ({
    Year: year,
    DataByPlantKey: plantKeys.map(plantKey => ({
      PlantKey: plantKey,
      Months: Array.from({ length: 12 }, (_, i) => ({
        Month: i + 1,
        ...categories.reduce((acc, category) => ({
          ...acc,
          [category]: purchases.filter(p => p.Year === year && p.Month === i + 1 && p.PlantKey === plantKey && p.DelayCategory === category).length
        }), {})
      }))
    }))
  }));

  //console.log('Final Output:', JSON.stringify(output, null, 2));  // Final structured data

  return { purchases: output };
};
