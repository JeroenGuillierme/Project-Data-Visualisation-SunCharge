<nav class="navbar">
	<a href="/" class="nav-link">Total Purchases</a>
  <a href="/DelaysperDC" class="nav-link">Purchase Delays per DC</a>
  <a href="/Table" class="nav-link">Table</a>
</nav>



<script>
    import Charts from './Chart.svelte';
    import './Styles.css'


  
    export let data = { purchases: [] }; // You would typically fetch this data or import it

</script>


<main>
  <h1>Purchase Delays Overview</h1>
  <Charts {data} />
</main>
