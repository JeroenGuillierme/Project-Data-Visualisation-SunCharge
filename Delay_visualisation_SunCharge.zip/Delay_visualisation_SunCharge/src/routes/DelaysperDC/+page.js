import Papa from 'papaparse';

export const load = async ({ fetch }) => {
  const response = await fetch('data/Purchases.csv');
  const csvText = await response.text();
  const { data } = Papa.parse(csvText, { header: true });

  const purchases = data.map(purchase => {
    // Convert dates and calculate delays
    const plannedGoodsReceiptDate = new Date(purchase.PlannedGoodsReceiptDate);
    const actualGoodsReceiptDate = new Date(purchase.ActualGoodsReceiptDate);
    const goodsReceiptDelay = (+actualGoodsReceiptDate - +plannedGoodsReceiptDate) / (86400000);

    const plannedArrivalDateYard = new Date(purchase.PlannedArrivalDateYard);
    const actualArrivalDateYard = new Date(purchase.ActualArrivalDateYard);
    const arrivalDateYardDelay = (+actualArrivalDateYard - +plannedArrivalDateYard) / (86400000);

    const plannedVendorShipmentDate = new Date(purchase.PlannedVendorShipmentDate);
    const actualVendorShipmentDate = new Date(purchase.ActualVendorShipmentDate);
    const vendorShipmentDelay = (+actualVendorShipmentDate - +plannedVendorShipmentDate) / (86400000);

    return {
      ...purchase,
      Year: plannedGoodsReceiptDate.getFullYear(),
      Month: plannedGoodsReceiptDate.getMonth() + 1,
      GoodsReceiptDelay: goodsReceiptDelay,
      ArrivalDateYardDelay: arrivalDateYardDelay,
      VendorShipmentDelay: vendorShipmentDelay
    };
  });

  // Unique years and plants
  const years = [...new Set(purchases.map(p => p.Year))].sort();
  const plants = [...new Set(purchases.map(p => p.PlantKey))];

  const output = years.map(year => {
    const monthsOutput = Array.from({ length: 12 }, (_, i) => {
      const month = i + 1;
      const plantDetails = plants.map(plantKey => {
        const plantData = { PlantKey: plantKey };
        ['GoodsReceiptDelay', 'ArrivalDateYardDelay', 'VendorShipmentDelay'].forEach(delayType => {
          plantData[delayType] = {
            'early': purchases.filter(p => p.Year === year && p.Month === month && p.PlantKey === plantKey && p[delayType] < 0).length,
            'on-time': purchases.filter(p => p.Year === year && p.Month === month && p.PlantKey === plantKey && p[delayType] === 0).length,
            '1-3 days late': purchases.filter(p => p.Year === year && p.Month === month && p.PlantKey === plantKey && p[delayType] > 0 && p[delayType] <= 3).length,
            'more than 3 days late': purchases.filter(p => p.Year === year && p.Month === month && p.PlantKey === plantKey && p[delayType] > 3).length
          };
        });
        return plantData;
      });
      return { Month: month, Plants: plantDetails };
    });
    return { Year: year, Months: monthsOutput };
  });

  //console.log('Final Output:', JSON.stringify(output, null, 2));

  return { 
    purchases: output
  };
};