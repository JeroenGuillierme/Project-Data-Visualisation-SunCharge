<script>
  import './Styles.css';

  export let data;

  let selectedYear = 2024;
  let selectedDelayType = 'GoodsReceiptDelay';
  let tooltip = '';
  let showTooltip = false; 
  let tooltipX;
  let tooltipY;
  let hoveredElement = null;


  const colors = {
      "early": "green",
      "on-time": "blue",
      "1-3 days late": "orange",
      "more than 3 days late": "red"
  };

  const colors2 = {
      "Antwerp DC": "red",
      "Wroclaw DC": "blue",
      "Lyon DC": "green",
      "Birmingham DC": "orange",
      "Göteborg DC": "purple"
  };

// Month names array for converting month number to name
const monthNames = ["January", "February", "March", "April", "May", "June", 
                      "July", "August", "September", "October", "November", "December"];
    const plantNames = {
        "4": "Antwerp DC",
        "5": "Wroclaw DC",
        "6": "Lyon DC",
        "7": "Birmingham DC",
        "8": "Göteborg DC"
    };

  const height = 450;
  let width = 1200;

  let svgElement;

  const options = [
      { value: 'GoodsReceiptDelay', label: 'Goods Receipt Delay' },
      { value: 'ArrivalDateYardDelay', label: 'Arrival Date Yard Delay' },
      { value: 'VendorShipmentDelay', label: 'Vendor Shipment Delay' }
  ];

  let filteredMonths = [];

  function getTotalByCategory(monthData) {
      const totals = { "early": 0, "on-time": 0, "1-3 days late": 0, "more than 3 days late": 0 };
      monthData.Plants.forEach(plant => {
          Object.keys(totals).forEach(key => {
              totals[key] += plant[selectedDelayType][key];
          });
      });
      return totals;
  }

  function getFilteredMonths() {
      const yearData = data.purchases.find(year => year.Year === selectedYear);
      return yearData ? yearData.Months.map(month => ({
          ...month,
          Totals: getTotalByCategory(month)
      })) : [];
  }

  $: filteredMonths = getFilteredMonths(), selectedYear, selectedDelayType;

  function getTotal(monthData) {
      return Object.values(monthData.Totals).reduce((acc, value) => acc + value, 0);
  }

  function showDetails(month, category, value, event) {


      const monthName = new Date(selectedYear, month.Month - 1).toLocaleString('en-UK', { month: 'long' });
      const percentage = (value / getTotal(month) * 100).toFixed(1);
      const totalPurchases = getTotal(month);

      const totalCategoryValue = month.Plants.reduce((sum, plant) => sum + plant[selectedDelayType][category], 0);

      const element = event.currentTarget;
      hoveredElement = element; // Set the hovered element
      element.style.opacity = '0.5'; // Reduce opacity to emphasize hover effect


      // Fixed tooltip location
      tooltipX = 1250; // Position to the right of the chart
      tooltipY = 200; // Below the chart



      // Initialize tooltip content
      tooltip = `<strong>Total Purchases ${monthName}/${selectedYear}: ${totalPurchases}</strong><br>`;
      tooltip += `<strong>${category}</strong>: ${value} (${percentage}%)<br>`;
      tooltip += `<svg width="150" height="150" viewBox="0 0 150 150" xmlns="http://www.w3.org/2000/svg">`;

      let startAngle = 0;
      let legendHTML = "<br><strong>Per Distribution Plant:</strong><br>";

      month.Plants.forEach((plant, index) => {
          const plantName = plantNames[plant.PlantKey] || "Unknown Plant";
          const plantValue = plant[selectedDelayType][category];
          const angle = (plantValue / totalCategoryValue) * 360;
          const endAngle = startAngle + angle;
          const largeArc = angle > 180 ? 1 : 0;
          const x1 = 75 + 70 * Math.cos(Math.PI * startAngle / 180);
          const y1 = 75 + 70 * Math.sin(Math.PI * startAngle / 180);
          const x2 = 75 + 70 * Math.cos(Math.PI * endAngle / 180);
          const y2 = 75 + 70 * Math.sin(Math.PI * endAngle / 180);
          const color = colors2[plantName];

          tooltip += `<path d="M 75 75 L ${x1} ${y1} A 70 70 0 ${largeArc} 1 ${x2} ${y2} z" fill="${color}" />`;

          // Update legend
          legendHTML += `<div style="color: ${color};">● ${plantName}: ${plantValue}</div>`;

          startAngle = endAngle;
      });

      tooltip += `</svg>`;
      tooltip += legendHTML;

      showTooltip = true;
  


      // console.log(`Tooltip coordinates: X=${tooltipX}, Y=${tooltipY}`);

  }

  function hideDetails() {
    if (hoveredElement) {
      hoveredElement.style.opacity = '1'; // Restore full opacity
    }
    showTooltip = false;
  }
</script>



  
  <!-- Dropdown for selecting delay type -->
  <div class="dropdown-container">
    <div class="dropdown-title">Select a Delay</div>
    <select bind:value={selectedDelayType} class="dropdown">
      {#each options as option}
        <option value={option.value}>{option.label}</option>
      {/each}
    </select>
  </div>
  
  <!-- SVG Chart -->
  <svg bind:this={svgElement} width={width+300} height={height+100}>
    {#each filteredMonths as month, monthIndex}
      <g transform={`translate(${width / filteredMonths.length * monthIndex}, 0)`}>
        {#each Object.entries(month.Totals) as [category, value], i}
          <rect
            bind:this={hoveredElement}
            data-original-color={colors[category]} 
            x={0}
            y={height - Object.values(month.Totals).slice(0, i + 1).reduce((a, b) => a + b, 0) / getTotal(month) * height}
            height={value / getTotal(month) * height}
            width={width / filteredMonths.length * 0.999}
            fill={colors[category]}
            opacity=1
            on:mouseover={event => showDetails(month, category, value, event)}
            on:mouseout={hideDetails}
            on:focus={event => showDetails(month, category, value, event)}
            on:blur={hideDetails}
          />
        {/each}
        <text x={width / getFilteredMonths().length * 0.3} y={height + 20} text-anchor="middle"> <!-- Month label below each bar -->
            {monthNames[month.Month - 1]} <!-- Using monthNames array for month name -->
        </text>
      </g>
    {/each}
    
      <!-- Legend -->
  <g transform="translate(750, 50)">
    {#each Object.entries(colors) as [key, color], i}
      <rect x={470} y={i * 30} width={20} height={20} fill={color} />
      <text x={500} y={i * 30 + 15} font-size="16px">{key}</text>
    {/each}
  </g>
    


    {#if showTooltip}
        <foreignObject x={tooltipX} y={tooltipY} width="250" height="150" style="overflow: visible;">
            <div class="tooltip" xmlns="http://www.w3.org/1999/xhtml">
                {@html tooltip} <!-- Render HTML tooltip content -->
            </div>
        </foreignObject>
    {/if}

  </svg>
  
  <!-- Year Slider -->
    <div class="slider-wrapper">
        <div class="slider-title">Select a Year</div>
        <div class="slider-container">
        <input type="range" min="2022" max="2024" bind:value={selectedYear} step="1" class="year-slider" />
        </div>
        <div class="slider-labels">
        <span>2022</span>
        <span>2023</span>
        <span>2024</span>
        </div>
    </div>
    