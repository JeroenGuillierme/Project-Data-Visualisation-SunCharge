import Papa from 'papaparse';

// Define a function to map PlantKey to DistributionPlant name
function getDistributionPlant(plantKey) {
    const distributionPlants = {
      '4': 'Antwerp DC',
      '5': 'Wroclaw DC',
      '6': 'Lyon DC',
      '7': 'Birmingham DC',
      '8': 'Göteborg DC'
    };
    return distributionPlants[plantKey] || 'Unknown'; // Default to 'Unknown' if no matching key is found
  }

export const load = async ({ fetch }) => {
  const response = await fetch('data/Purchases.csv');
  const csvText = await response.text();
  const { data } = Papa.parse(csvText, { header: true });

  const purchases = data.map(purchase => {
    // Goods Receipt Dates
    const plannedGoodsReceiptDate = new Date(purchase.PlannedGoodsReceiptDate);
    const actualGoodsReceiptDate = new Date(purchase.ActualGoodsReceiptDate);
    const goodsReceiptDelay = (+actualGoodsReceiptDate - +plannedGoodsReceiptDate) / (86400000); // milliseconds to days

    let categoryGoodsReceipt;
    if (goodsReceiptDelay < 0) {
        categoryGoodsReceipt = 'early';
    } else if (goodsReceiptDelay === 0) {
        categoryGoodsReceipt = 'on-time';
    } else if (goodsReceiptDelay > 0 && goodsReceiptDelay <= 3) {
        categoryGoodsReceipt = '1-3 days late';
    } else if (goodsReceiptDelay > 3) {
        categoryGoodsReceipt = 'more than 3 days late';
    }
    
    // Arrival Date Yard
    const plannedArrivalDateYard = new Date(purchase.PlannedArrivalDateYard);
    const actualArrivalDateYard = new Date(purchase.ActualArrivalDateYard);
    const arrivalDateYardDelay = (+actualArrivalDateYard - +plannedArrivalDateYard) / (86400000); // milliseconds to days

    let categoryArrivalDateYard;
    if (arrivalDateYardDelay < 0) {
        categoryArrivalDateYard = 'early';
    } else if (arrivalDateYardDelay === 0) {
        categoryArrivalDateYard = 'on-time';
    } else if (arrivalDateYardDelay > 0 && arrivalDateYardDelay <= 3) {
        categoryArrivalDateYard = '1-3 days late';
    } else if (arrivalDateYardDelay > 3) {
        categoryArrivalDateYard = 'more than 3 days late';
    }


    // Vendor Shipment Date
    const plannedVendorShipmentDate = new Date(purchase.PlannedVendorShipmentDate);
    const actualVendorShipmentDate = new Date(purchase.ActualVendorShipmentDate);
    const vendorShipmentDelay = (+actualVendorShipmentDate - +plannedVendorShipmentDate) / (86400000); // milliseconds to days

    let categoryVendorShipment;
    if (vendorShipmentDelay < 0) {
        categoryVendorShipment = 'early';
    } else if (vendorShipmentDelay === 0) {
        categoryVendorShipment = 'on-time';
    } else if (vendorShipmentDelay > 0 && vendorShipmentDelay <= 3) {
        categoryVendorShipment = '1-3 days late';
    } else if (vendorShipmentDelay > 3) {
        categoryVendorShipment = 'more than 3 days late';
    }

     // Assign DistributionPlant based on PlantKey
     const distributionPlant = getDistributionPlant(purchase.PlantKey);

    return {
      ...purchase,
      Year: plannedGoodsReceiptDate.getFullYear(),
      Month: plannedGoodsReceiptDate.getMonth()+1, // JavaScript months are 0-indexed
      GoodsReceiptDelay: goodsReceiptDelay,
      GoodsReceiptDelayCategory: categoryGoodsReceipt,
      ArrivalDateYardDelay: arrivalDateYardDelay,
      ArrivalDateYardDelayCategory: categoryArrivalDateYard,
      VendorShipmentDelay: vendorShipmentDelay,
      VendorShipmentDelayCategory: categoryVendorShipment,
      DistributionPlant:distributionPlant
    };
  });


  //console.log('Final Output:', JSON.stringify(purchases, null, 2));  // Final structured data

  return{
    purchasesDelays:purchases
  }
  
}
