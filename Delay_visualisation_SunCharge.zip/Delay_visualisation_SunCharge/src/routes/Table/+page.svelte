<nav class="navbar">
	<a href="/" class="nav-link">Total Purchases</a>
  <a href="/DelaysperDC" class="nav-link">Purchase Delays per DC</a>
  <a href="/Table" class="nav-link">Table</a>
</nav>

<script>
    export let data;
    import './Styles.css'
</script>

<table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Distribution Plant</th>
        <th>Planned Goods Receipt Date</th>
        <th>Actual Goods Receipt Date</th>
        <th> Delay G.R.D. (Days)</th>
        <th> Delay Category G.R.D.</th>
        <th>Planned Arrival Date Yard</th>
        <th>Actual Arrival Date Yard</th>
        <th> Delay A.D.Y. (Days)</th>
        <th> Delay Category A.D.Y. </th>
        <th>Planned Vendor Shipment Date</th>
        <th>Actual Vendor Shipment Date</th>
        <th> Delay V.S.D. (Days)</th>
        <th> Delay Category V.S.D. </th>
      </tr>
    </thead>
    <tbody>
      {#each data.purchasesDelays as purchase}
        <tr>
          <td>{purchase.PurchaseOrder}</td>
          <td> {purchase.DistributionPlant}</td>
          <td> {purchase.PlannedGoodsReceiptDate}</td>
          <td>{purchase.ActualGoodsReceiptDate}</td>
          <td>{purchase.GoodsReceiptDelay}</td>
          <td>{purchase.GoodsReceiptDelayCategory}</td>
          <td> {purchase.PlannedArrivalDateYard}</td>
          <td>{purchase.ActualArrivalDateYard}</td>
          <td>{purchase.ArrivalDateYardDelay}</td>
          <td>{purchase.ArrivalDateYardDelayCategory}</td>
          <td> {purchase.PlannedVendorShipmentDate}</td>
          <td>{purchase.ActualVendorShipmentDate}</td>
          <td>{purchase.VendorShipmentDelay}</td>
          <td>{purchase.VendorShipmentDelayCategory}</td>
        </tr>
      {/each}
    </tbody>
  </table>