<nav class="navbar">
	<a href="/" class="nav-link">Total Purchases</a>
  <a href="/DelaysperDC" class="nav-link">Purchase Delays per DC</a>
  <a href="/Table" class="nav-link">Table</a>
</nav>

<script>
  export let data; // Assumes this is passed in as a prop from +page.js
  import LineChart from './LineChart.svelte'
  import './Styles.css'

  let selectedYear = 2024
</script>

<main>
<h1> Evolution number of purchases over the years (per distribution plant) </h1>
{#each data.purchases as yearData}
  {#if yearData.Year === selectedYear}
    <LineChart data={yearData.DataByPlantKey}/>
  {/if}
{/each}

</main>

  <!-- Year Slider -->
  <div class="slider-wrapper">
    <div class="slider-title">Select a Year</div>
    <div class="slider-container">
    <input type="range" min="2022" max="2024" bind:value={selectedYear} step="1" class="year-slider" />
    </div>
    <div class="slider-labels">
    <span>2022</span>
    <span>2023</span>
    <span>2024</span>
    </div>
</div>
