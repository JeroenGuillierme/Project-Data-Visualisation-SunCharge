<script>
  export let data;
  import './Styles.css';

  let width = 960;
  let height = 500;
  let margin = { top: 20, right: 120, bottom: 50, left: 40 };
  let tooltipVisible = false;
  let tooltipContent = "";
  let tooltipX = 0;
  let tooltipY = 0;

  let months = ["January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"];

  const plantNames = {
    "4": "Antwerp DC",
    "5": "Wroclaw DC",
    "6": "Lyon DC",
    "7": "Birmingham DC",
    "8": "Göteborg DC"
  };

  function getPlantName(plantKey) {
    return plantNames[plantKey] || `Plant ${plantKey}`;
  }

  function getTotalSalesByMonth(data) {
      const totals = Array(12).fill(0);
      data.forEach(plant => {
          plant.Months.forEach((month, index) => {
              totals[index] += month.early + month['on-time'] + month['1-3 days late'] + month['more than 3 days late'];
          });
      });
      return totals;
  }

  const totalSalesByMonth = getTotalSalesByMonth(data);

  const xScale = (month) => {
    return ((month - 1) / 11) * (width - margin.left - margin.right) + margin.left;
  };

  const getMaxY = () => {
    let max = 0;
    data.forEach(plant => {
      plant.Months.forEach(month => {
        let total = month.early + month['on-time'] + month['1-3 days late'] + month['more than 3 days late'];
        if (total > max) max = total;
      });
    });
    const totalMax = Math.max(...totalSalesByMonth);
    return Math.max(max, totalMax);
  };

  const yScale = (value) => {
    const maxY = getMaxY();
    return height - margin.bottom - (value / maxY) * (height - margin.top - margin.bottom);
  };

  const linePath = (months) => {
    return months.map((month, i) => {
      const total = month.early + month['on-time'] + month['1-3 days late'] + month['more than 3 days late'];
      return `${i === 0 ? 'M' : 'L'}${xScale(i + 1)} ${yScale(total)}`;
    }).join(' ');
  };

  function showTooltip(plant, monthIndex, isTotal = false) {
    let tooltipData;
    let xPos = xScale(monthIndex + 1); // Get the x position from the scale directly
    let yPos = isTotal ? yScale(totalSalesByMonth[monthIndex]) : yScale(plant.Months[monthIndex].early + plant.Months[monthIndex]['on-time'] + plant.Months[monthIndex]['1-3 days late'] + plant.Months[monthIndex]['more than 3 days late']);

    if (isTotal) {
      tooltipData = `<strong>Total Purchases in ${months[monthIndex]}:</strong> ${totalSalesByMonth[monthIndex]}`;
    } else {
      const month = plant.Months[monthIndex];
      tooltipData = `<strong>${months[monthIndex]} ${getPlantName(plant.PlantKey)}:</strong> ${month.early + month['on-time'] + month['1-3 days late'] + month['more than 3 days late']}
      <br> - Early: ${month.early}
      <br> - On-time: ${month['on-time']}
      <br> - 1-3 days late: ${month['1-3 days late']}
      <br> - More than 3 days late: ${month['more than 3 days late']}`;
    }
    tooltipVisible = true;
    tooltipContent = tooltipData;
    tooltipX = xPos - 200 / 2; // Center the tooltip on the circle
    tooltipY = yPos - 100 - 10; // Position above the circle

    if (tooltipX < margin.left) tooltipX = margin.left;
    if (tooltipX + 200 > width - margin.right) tooltipX = width - margin.right - 200;
    if (tooltipY < margin.top) tooltipY = margin.top;
  }

  function hideTooltip() {
    tooltipVisible = false;
  }

  const maxY = getMaxY();
  const numYTicks = 10; // Number of ticks on the y-axis
  const yTickStep = maxY / numYTicks;
  const yTicks = Array.from({length: numYTicks + 1}, (_, i) => i * yTickStep);

  function formatNumber(num) {
    return num.toFixed(0); // Change formatting as needed
  }

</script>

<style>
  .tooltip {
    background: white;
    border: 1px solid black;
    padding: 10px;
    font-size: 12px;
    line-height: 1.4;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.5);
    pointer-events: none;
  }
</style>

<svg width={width} height={height + 100}>
  {#each data as plant, plantIndex (plant.PlantKey)}
    <path 
      d={linePath(plant.Months)} 
      fill="none" 
      stroke="hsl({plantIndex * 60 % 360}, 70%, 50%)" 
      stroke-width="2"
    ></path>
    {#each plant.Months as month, monthIndex}
      <circle 
        cx={xScale(monthIndex + 1)} 
        cy={yScale(month.early + month['on-time'] + month['1-3 days late'] + month['more than 3 days late'])}
        r="5"
        fill="hsl({plantIndex * 60 % 360}, 70%, 50%)"
        on:mouseover="{() => showTooltip(plant, monthIndex, false)}"
        on:mouseout="{hideTooltip}"
        tabindex="0">
      </circle>
    {/each}
    <!-- Legend -->
    <rect x={width - 110} y={20 * plantIndex} width="18" height="18" fill="hsl({plantIndex * 60 % 360}, 70%, 50%)"/>
    <text x={width - 85} y={20 * plantIndex + 14} font-size="15px">{getPlantName(plant.PlantKey)}</text>
  {/each}

  <!-- Total Purchases Line -->
  <path
    d={linePath(months.map((_, index) => ({early: 0, 'on-time': 0, '1-3 days late': 0, 'more than 3 days late': totalSalesByMonth[index]})))}
    fill="none"
    stroke="black"
    stroke-width="3"
  ></path>
  <!-- Circles for Total Purchases -->
  {#each totalSalesByMonth as total, index}
    <circle 
      cx={xScale(index + 1)} 
      cy={yScale(total)}
      r="5"
      fill="black"
      on:mouseover="{() => showTooltip({}, index, true)}"
      on:mouseout="{hideTooltip}"
      tabindex="0">
    </circle>
  {/each}

  <!-- Legend for Total Purchases -->
  <rect x={width - 110} y={20 * (data.length)} width="18" height="18" fill="black"/>
  <text x={width - 85} y={20 * (data.length) + 14} font-size="15px">Total Purchases</text>

  <!-- Axes and Labels -->
  <line x1={margin.left} y1={height - margin.bottom} x2={width - margin.right} y2={height - margin.bottom} stroke="#000" />
  <line x1={margin.left} y1={margin.top} x2={margin.left} y2={height - margin.bottom} stroke="#000" />
  <text x={margin.left - 30} y={(height - margin.top - margin.bottom) / 2 + margin.top} transform={`rotate(-90, ${margin.left - 30}, ${(height - margin.top - margin.bottom) / 2 + margin.top})`} text-anchor="middle">Number of Purchases</text>
  {#each yTicks as tick}
    <text x={margin.left - 10} y={yScale(tick)} dy="0.32em" text-anchor="end">{formatNumber(tick)}</text>
  {/each}
  {#each months as month, i}
    <text x={xScale(i+1)} y={height - margin.bottom + 20} text-anchor="middle">{month}</text>
  {/each}
  <line x1={margin.left} y1={margin.top} x2={margin.left} y2={height - margin.bottom} stroke="#000" />
  {#each yTicks as tick}
    <line x1={margin.left} y1={yScale(tick)} x2={width - margin.right} y2={yScale(tick)} stroke="#eee" stroke-dasharray="2,2" />
  {/each}

  <!-- Tooltip -->
  {#if tooltipVisible}
    <foreignObject x={tooltipX} y={tooltipY} width="200" height="100" style="pointer-events:none;">
      <div class="tooltip" xmlns="http://www.w3.org/1999/xhtml">
        {@html tooltipContent}
      </div>
    </foreignObject>
  {/if}
</svg>
