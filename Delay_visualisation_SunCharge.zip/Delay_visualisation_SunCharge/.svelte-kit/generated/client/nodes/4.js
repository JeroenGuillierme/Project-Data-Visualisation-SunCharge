import * as universal from "../../../../src/routes/Table/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/Table/+page.svelte";